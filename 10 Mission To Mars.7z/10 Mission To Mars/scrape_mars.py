from splinter import Browser
from bs4 import BeautifulSoup as bs
import pandas as pd
import time


def init_browser():
    # @NOTE: Replace the path with your actual path to the chromedriver
    executable_path = {"executable_path": "chromedriver.exe"}
    return Browser("chrome", **executable_path, headless=False)


def scrape():
    browser = init_browser()


    url = "https://mars.nasa.gov/news/"
    browser.visit(url)

    html = browser.html
    soup = bs(html, "html.parser")

    news_content=soup.find_all("div", class_="content_title")[0]
    news_title = news_content.find("a").text
    print(news_title)

    news_p = soup.find_all("div", class_="article_teaser_body")[0].text

    print(news_p)


    url = "https://www.jpl.nasa.gov/spaceimages/"
    browser.visit(url)

    html = browser.html

    browser.click_link_by_partial_text("FULL IMAGE")

    soup = bs(html,"html.parser")

    #import ipdb;ipdb.set_trace()

    full_url = soup.find_all("article", class_="carousel_item")[0]["style"]
    featured_image_url = "https://www.jpl.nasa.gov" + full_url[ full_url.find("'")+1 : full_url.find(";")-2   ] 

    print(full_url)
    print(featured_image_url)

    url = "https://twitter.com/marswxreport?lang=en"
    browser.visit(url)
    html = browser.html
    soup = bs(html,"html.parser")

    contents = soup.find_all("div",class_="content")

    for content in contents:
        
        if (content.p) :
            print("-------------")
            textos = content.find("p").text
            
            if textos[0:3]=="Sol":
                print(textos)
                mars_weather = textos[ :textos.find("daylight")+20 ]
                break

    print("................")
    print(mars_weather)


    url = "https://space-facts.com/mars/"
    tables = pd.read_html(url)
    df = tables[0]
    df.columns = ["Parameter", "Value"]
    df.set_index("Parameter",inplace=True)
    df

    html_table = df.to_html()
    html_table = html_table.replace('\n','')
    html_table




    data ={
        "news_title":news_title,
        "news_p" : news_p,
        "featured_image_url" : featured_image_url,
        "mars_weather" : mars_weather,
        "mars_facts" : html_table
    }


    print("End of Scrap")
    # Quite the browser after scraping
    browser.quit()

    # Return results
    return data